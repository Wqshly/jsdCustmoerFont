// api的导出
import getRequestApi from '@/request/api/getRequest'
import postRequestApi from '@/request/api/postReuestApi'

export default {
  getRequestApi,
  postRequestApi
}
