// api的导出
import bgLogin from '@/request/img/login'
import bgRegister from '@/request/img/register'

export default {
  bgLogin,
  bgRegister
}
