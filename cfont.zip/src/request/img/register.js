import bg1 from '@/assets/img/register/1.jpg'
import bg2 from '@/assets/img/register/2.jpg'
import bg3 from '@/assets/img/register/3.jpg'
import bg4 from '@/assets/img/register/4.jpg'
import bg5 from '@/assets/img/register/5.jpg'
import bg6 from '@/assets/img/register/6.jpg'
import bg7 from '@/assets/img/register/7.jpg'
import bg8 from '@/assets/img/register/8.jpg'
import bg9 from '@/assets/img/register/9.jpg'

export default [bg1, bg2, bg3, bg4, bg5, bg6, bg7, bg8, bg9]
