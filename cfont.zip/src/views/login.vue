<template>
  <div class="fill-contain"
       :style="{backgroundImage: 'url(' + backgroundImg + ')', backgroundSize:'cover',backgroundAttachment: 'fixed',backgroundRepeat: 'no-repeat'}">
    <div class="form-container">
      <el-tabs v-model="activeName" :stretch="true" type="card" @tab-click="handleClick">
        <el-tab-pane label="用户名登陆" name="first">
          <section class="main-form">
            <el-form :model="loginForm" style="padding-top: 30px" :rules="rules" ref="loginForm">
              <el-form-item prop="username">
                <el-input v-model="loginForm.username" placeholder="请输入用户名"
                          prefix-icon="el-icon-wqs-shezhi-zhanghaoguanli"
                          clearable/>
              </el-form-item>
              <el-form-item style="margin-bottom: 20px;" prop="password">
                <el-input type="password" v-model="loginForm.password" placeholder="请输入密码"
                          prefix-icon="el-icon-wqs-suoding"
                          clearable/>
              </el-form-item>
              <sliding-verification ref="slidingVerification" :key="timer2"></sliding-verification>
              <el-form-item style="margin-bottom: 5px;">
                <el-link :underline="false" style="float: left;margin-left: 10px" @click="register">没有账号？点击注册</el-link>
                <el-checkbox style="float: right;margin-right: 10px">记住密码</el-checkbox>
              </el-form-item>
              <el-form-item>
                <el-button class="login-btn" @click="login('loginForm')">登录</el-button>
              </el-form-item>
            </el-form>
          </section>
        </el-tab-pane>
        <el-tab-pane label="手机验证码登录" name="second">
          <section class="main-form">
            <el-form :model="codeLoginForm" ref="codeLoginForm" style="margin-top: 30px">
              <el-form-item prop="phoneNumber">
                <el-input v-model="codeLoginForm.phoneNumber" prefix-icon="el-icon-wqs-Mobile" placeholder="请输入手机号"
                          clearable></el-input>
              </el-form-item>
              <el-form-item>
                <el-input v-model="codeLoginForm.vcode" style="width: 200px" class="el-input-vcode"
                          prefix-icon="el-icon-wqs-yanzhengma3" placeholder="输入右侧图形验证码" clearable></el-input>
                <i style="float: right;margin: 12px;cursor: pointer;" class="el-icon-wqs-shuaxin"
                   @click="refreshVCode"></i>
                <valid-code ref="validCode" style="float: right" @update:value="compareVCode"></valid-code>
              </el-form-item>
              <el-alert style="margin-bottom: 10px;" :title="alertContext" type="warning" show-icon v-show="alert"
                        :closable="false"></el-alert>
              <el-form-item>
                <el-input v-model="codeLoginForm.phoneCode" class="el-input-vcode" prefix-icon="el-icon-wqs-yanzhengma4" placeholder="请输入手机短信验证码"
                          clearable></el-input>
                <el-button v-show="show" class="el-button-vcode" @click="getCode">获取短信验证码</el-button>
                <span v-show="!show" class="el-button-vcode cant-select">{{count + 's后可重新发送'}}</span>
              </el-form-item>
              <el-form-item>
                <el-button class="login-btn" @click="login">登录</el-button>
              </el-form-item>
            </el-form>
          </section>
        </el-tab-pane>
        <el-tab-pane label="app扫码登录" name="third">
          <section class="main-form">
          </section>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script>
import ValidCode from '@/components/ValidCode'
import SlidingVerification from '@/components/SlidingVerification'

export default {
  data: function () {
    const bgLogin = this.$img.bgLogin
    return {
      loginForm: {
        username: null,
        password: null
      },
      codeLoginForm: {
        phoneNumber: null,
        vcode: null,
        phoneCode: null
      },
      rules: {
        username: [
          {required: true, message: '请输入用户名', trigger: 'blur'},
          {min: 2, max: 11, message: '请输入正确的用户名', trigger: 'blur'}
        ],
        password: [
          {required: true, message: '请输入密码', trigger: 'blur'}
        ]
      },
      activeName: 'first',
      show: true,
      count: '',
      timer: null,
      timer2: '',
      alert: false,
      VCodeValue: null,
      alertContext: '',
      bgLogin: bgLogin
    }
  },
  components: {
    ValidCode,
    SlidingVerification
  },
  computed: {
    loginCode () {
      return this.codeLoginForm.vcode
    },
    backgroundImg () {
      const randIndex = Math.floor(Math.random() * this.bgLogin.length)
      return this.bgLogin[randIndex]
    }
  },
  watch: {
    loginCode (value) {
      if (value === null || value === '') {
        this.alert = true
        this.alertContext = '验证码不能为空'
      } else if (value !== null && value !== '' && this.VCodeValue !== value) {
        this.alert = true
        this.alertContext = '验证码输入错误'
      } else {
        this.alert = false
      }
      console.log(value)
    },
    VCodeValue (value) {
      this.codeLoginForm.vcode = null
      this.alert = false
    }
  },
  methods: {
    handleClick (tab, event) {
      console.log(tab, event)
    },
    login () {
      const url = '/customer/login' + (this.activeName === 'first' ? '&username=' + this.loginForm.username + '&password=' + this.loginForm.password : '&username=' + this.codeLoginForm.phoneNumber + '&code=' + this.codeLoginForm.phoneCode)
      if (!this.$refs.slidingVerification.confirmSuccess) {
        this.$message({
          message: '请先完成拖动滑块功能',
          type: 'error'
        })
      } else {
        this.$api.getRequestApi.get(url)
          .then(res => {
            if (res.data.code === 0) {
              sessionStorage.setItem('save_username', this.loginForm.username)
              this.$router.push('/home')
            }
          })
          .catch(err => {
            console.log(err.data)
            console.log(this.url)
            this.timer2 = new Date().getTime()
            return false
          })
      }
    },
    verLogin () {
      this.$router.push('/home')
    },
    getCode () {
      const TIME_COUNT = 60
      this.$api.getRequestApi.get('/customer/verLogin')
        .then(res => {
          if (res.code) {
            if (!this.timer) {
              this.count = TIME_COUNT
              this.show = false
              this.timer = setInterval(() => {
                if (this.count > 0 && this.count <= TIME_COUNT) {
                  this.count--
                } else {
                  this.show = true
                  clearInterval(this.timer)
                  this.timer = null
                }
              }, 1000)
            }
          }
        })
        .catch(err => {
          this.$message({
            message: '无网络，请求失败，请检查您的网络连接',
            type: 'error'
          })
          console.log(err.code)
        })
    },
    register () {
      this.$router.push('/register')
    },
    compareVCode (codeList) {
      this.VCodeValue = codeList
    },
    refreshVCode () {
      this.$refs.validCode.refreshCode()
    }
  },
  mounted () {
  }
}

</script>

<style lang="less" scoped>
  @import "../style/style";

  .form-container {
    .global-centre(460px, 380px);
    .width-and-height(460px, 380px);
  }

  .login-button {
    width: 420px;
    height: 40px;
  }

  .el-input-vcode {
    float: left;
    width: 250px;
  }

  .el-button-vcode {
    float: right;
    width: 140px;
  }

  .login-btn {
    width: 400px;
  }

</style>
